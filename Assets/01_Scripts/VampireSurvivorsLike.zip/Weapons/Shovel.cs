using Unity.VisualScripting;
using UnityEngine;

public class Shovel : Weapons
{
    public override void SetVelocity()
    {
        if (Database.IsUnityNull())
        {
            return;
        }
        rotationSpeed = Database.Shovel.OriginAngularVelocity;
        additionalRotationSpeed = Database.Shovel.AdditionalAngularVelocity;
        base.SetVelocity();
    }

    protected override void OnTriggerEnter2D(Collider2D _collision)
    {
        damage = Database.Shovel.Damage * Database.OriginAttack * Database.AdditionalAttack;
        //�����̸� �ְų� ť �̿��ؼ� �����ð� �߰�.
        base.OnTriggerEnter2D(_collision);
    }
}
